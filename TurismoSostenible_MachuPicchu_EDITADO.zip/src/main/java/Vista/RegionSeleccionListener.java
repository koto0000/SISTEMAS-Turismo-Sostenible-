package Vista;

public interface RegionSeleccionListener {
    void onRegionSeleccionada(String nombreRegion);
        void onLugarBuscado(String nombreLugar); // ← nueva función

}