
import java.awt.*;
import javax.swing.*;

public class PanelReserva extends JPanel {
    
    public PanelReserva() {
        setLayout(new BorderLayout());
        aplicarEstilo(this);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        ImageIcon bg = new ImageIcon(getClass().getResource("/Imagenes/machupicchu.png"));
        g.drawImage(bg.getImage(), 0, 0, getWidth(), getHeight(), this);
    }

    private void aplicarEstilo(Component comp) {
        if (comp instanceof JButton) {
            comp.setBackground(new Color(30, 58, 138)); // azul profundo
            comp.setForeground(Color.WHITE);
        } else if (comp instanceof JLabel) {
            comp.setForeground(new Color(255, 215, 0)); // dorado
        } else if (comp instanceof JPanel) {
            comp.setBackground(new Color(25, 25, 112, 180)); // azul translúcido
        }
        if (comp instanceof Container) {
            for (Component child : ((Container) comp).getComponents()) {
                aplicarEstilo(child);
            }
        }
    }
}
